enum FloatingSheetType {
  priority,
  remind,
  assign,
  deadline,
  workType,
  folder,        // 🆕
  clientName,    // 🆕
}