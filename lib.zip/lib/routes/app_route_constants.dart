class AppRoutesName{
  static const String Loginroutename = "login";
  static const String Adminroutename = "admin";
  static const String JobForm ="job_form";
  static const String DashboardScreen ="DashboardScreen";
  static const String MapScreen ="MapScreen";
  static const String PaymentScreen ="PaymentScreen";
  static const String AnalyticsScreen ="AnalyticsScreen";
  static const String Home ="Home";
  static const String TaskDetail = "TaskDetail";
  static const String TasksPage = "TasksPage";
  static const String GraphPage = "GraphPage";
}