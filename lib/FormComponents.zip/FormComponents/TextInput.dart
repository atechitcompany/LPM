import 'package:flutter/material.dart';

class Textinput extends StatefulWidget {
  final String label;
  final String hint;
  const Textinput({
    super.key,
    required this.label,
    required this.hint,
  });


  @override
  State<Textinput> createState() => _TextinputState();
}

class _TextinputState extends State<Textinput> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [Text(widget.label),
        SizedBox(
          height: 5,
        ),
        TextField(
          decoration: InputDecoration(
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(6)),
              hintText: widget.hint),
        ),]
    );
  }
}
