import 'package:flutter/material.dart';

class NumberStepper extends StatefulWidget {
  final double step;            // Example: 1, 0.1, 0.01
  final double initialValue;    // Starting number
  final Function(double) onChanged;

  const NumberStepper({
    super.key,
    required this.step,
    required this.onChanged,
    this.initialValue = 0,
  });

  @override
  State<NumberStepper> createState() => _NumberStepperState();
}

class _NumberStepperState extends State<NumberStepper> {
  late double value;

  @override
  void initState() {
    super.initState();
    value = widget.initialValue;
  }

  String formatNumber(double number) {
    if (number % 1 == 0) {
      return number.toInt().toString(); // removes .0
    } else {
      return number.toStringAsFixed(3).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              formatNumber(value),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),

        const SizedBox(width: 8),

        /// INCREMENT BUTTON
        GestureDetector(
          onTap: () {
            setState(() => value += widget.step);
            widget.onChanged(value);
          },
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              color: Colors.yellow,
            ),
            child: const Text("+", style: TextStyle(fontSize: 24)),
          ),
        ),
        const SizedBox(width: 8),

        /// DECREMENT BUTTON
        GestureDetector(
          onTap: () {
            setState(() => value -= widget.step);
            widget.onChanged(value);
          },
          child: Container(
            padding: const EdgeInsets.all(14),
            width: 40,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              color: Colors.yellow,
            ),
            child: Center(child: Text("-", style: TextStyle(fontSize: 24))),
          ),
        ),
      ],
    );
  }
}
