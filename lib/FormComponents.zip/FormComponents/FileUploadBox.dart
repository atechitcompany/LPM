import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

class FileUploadBox extends StatefulWidget {
  final Function(PlatformFile file) onFileSelected;

  const FileUploadBox({super.key, required this.onFileSelected});

  @override
  State<FileUploadBox> createState() => _FileUploadBoxState();
}

class _FileUploadBoxState extends State<FileUploadBox> {
  PlatformFile? selectedFile;

  Future<void> pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: false, // you can make it true for multiple files
      withData: true,
    );

    if (result != null && result.files.isNotEmpty) {
      setState(() {
        selectedFile = result.files.first;
      });

      widget.onFileSelected(selectedFile!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: pickFile,
      child: Container(
        height: 140,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: selectedFile == null
              ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.upload_file, size: 30),
              SizedBox(height: 8),
              Text("Drop here to attach or upload"),
              SizedBox(height: 4),
            ],
          )
              : Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.insert_drive_file,
                  size: 30, color: Colors.blue),
              const SizedBox(height: 8),
              Text(
                selectedFile!.name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "${(selectedFile!.size / (1024 * 1024)).toStringAsFixed(2)} MB",
                style:
                const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
