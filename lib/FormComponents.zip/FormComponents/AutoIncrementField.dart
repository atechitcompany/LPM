import 'package:flutter/material.dart';

class AutoIncrementField extends StatelessWidget {
  final int value;
  const AutoIncrementField({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("LPM *", style: TextStyle(fontSize: 14)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD2D5DA)),
              borderRadius: BorderRadius.circular(6)),
          child: Text(
            value.toString(),
            style: const TextStyle(fontSize: 16, color: Color(0xFF4B5563)),
          ),
        )
      ],
    );
  }
}
